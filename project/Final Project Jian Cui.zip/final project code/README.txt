use project(number) to run the program
%         1 is check if the checkCollision works
%         2 is check if the qStart and qEnd can be connected to sample
%         3 is draw the path for PRM, when sample is 50
%         4 is count the visited points for different h(n) 